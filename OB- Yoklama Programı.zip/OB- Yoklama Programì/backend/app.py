from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///face_recognition_db.sqlite'
db = SQLAlchemy(app)

class FaceRecognition(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    face_id = db.Column(db.String(50), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False)

def save_to_database(face_id):
    last_entry = FaceRecognition.query.filter_by(face_id=face_id).order_by(FaceRecognition.timestamp.desc()).first()
    if last_entry and (datetime.now() - last_entry.timestamp) < timedelta(hours=1):
        print(f"{face_id} için kayıt atlanıyor, çünkü 1 saatten az bir süre geçti.")
        return
    new_entry = FaceRecognition(face_id=face_id, timestamp=datetime.now())
    db.session.add(new_entry)
    db.session.commit()

@app.route('/recognize_face', methods=['POST'])
def recognize_face():
    data = request.json
    face_id = data.get('face_id')

    if face_id:
        save_to_database(face_id)
        return jsonify({"message": "Yüz tanımlandı ve başarıyla kaydedildi."}), 200
    else:
        return jsonify({"error": "Yüz kimliği sağlanmadı."}), 400

@app.route('/')
def index():
    today = datetime.now().date()
    yesterday = today - timedelta(days=1)

    today_entries = db.session.query(FaceRecognition).filter(func.date(FaceRecognition.timestamp) == today).all()
    yesterday_entries = db.session.query(FaceRecognition).filter(func.date(FaceRecognition.timestamp) == yesterday).all()

    data = {
        str(today): today_entries,
        str(yesterday): yesterday_entries
    }

    return render_template('index.html', data=data)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
